package com.niit.dao;


import java.util.List;

import com.niit.model.Employee;;

public interface EmployeeDAO {

	public List<Employee> listEmployee();
	
}